Train-X: статическая версия для GitHub Pages / Cloudflare Pages

Состав:
index.html — главная страница;
trainx-3d.html — исходный автономный HTML-просмотрщик 3D;
concept-render.png — художественная иллюстрация (не технический чертёж);
.nojekyll — отключение Jekyll для GitHub Pages.

Это РЕКОНСТРУКЦИЯ ПО ПУБЛИЧНОМУ СОДЕРЖИМОМУ, а не точная копия исходного сайта ChatGPT Sites.

ВНИМАНИЕ: исходная форма сбора обращений заменена ссылкой mailto:.
Сохранение заявок в журнал, выдача номера обращения и серверные функции не перенесены.

GitHub Pages (ручная загрузка):
1. На github.com создайте НОВЫЙ репозиторий, например trainx-site, Public.
2. Add file -> Upload files: поместите в корень ВСЕ файлы из этой папки (не сам ZIP).
3. Commit changes.
4. Settings -> Pages -> Build and deployment -> Source: Deploy from a branch -> Branch: main / (root) -> Save.
5. Публичный URL будет https://USERNAME.github.io/trainx-site/.

Cloudflare Pages: Workers & Pages -> Create -> Pages -> Upload assets; загрузите папку как статический сайт.

Опубликованный сайт и встроенный 3D-просмотрщик доступны любому с ссылкой: если точные механические детали не должны быть публичными до подачи патента, удалите trainx-3d.html или закройте этот раздел перед публикацией.
